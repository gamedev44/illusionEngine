goto the windows icon or the system search and search
for " Change the Mouse Pointer Display or Speed " and click the box that comes up...
navigate to the pointers tab in the window that opens and below the pointer is a drop down of other various pointers and below that is says Browse Click the "Browse" Button 

and copy the cursor i gave you into the cursor files , 

                         then select it as the new cursor and click APPLY...


( if you followed these steps prperly then your cursor should now be an pumpkin themed imp )



